          Console-Based Budget Tracker

This is a console-based budget tracker written in Python 3.12.2. It allows users to manage their expenses and income, calculate budgets, and analyze spending trends.


Features:


Expense and Income Entry: Users can input expenses and income with categories and amounts.
Budget Calculation: The application calculates the remaining budget after deducting expenses from income.
Expense Analysis: Provides insights by categorizing expenses and displaying spending trends.
Data Persistence: Transactions are stored in a file/database for tracking  over time.


Tech Stack:


python 3.12.2: The application is written in Python 3.12.2.
File Handling or Database Library: Transactions are stored for persistence


Installation

    

Navigate to the project directory:
     cd budget-tracker

Run the application

     python budget_tracker.py


