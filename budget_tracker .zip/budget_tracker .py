import json

# Function to input expenses or income
def input_transaction():
    category = input("Enter category: ")
    amount = float(input("Enter amount: "))
    return {"category": category, "amount": amount}

# Function to calculate remaining budget
def calculate_budget(income, expenses):
    remaining_budget = income - sum(expenses)
    return remaining_budget

# Function to analyze expenses
def analyze_expenses(expenses):
    categories = {}
    for expense in expenses:
        category = expense["category"]
        amount = expense["amount"]
        categories[category] = categories.get(category, 0) + amount
    return categories

# Function to save transactions to a file
def save_transactions(transactions):
    with open("transactions.json", "w") as file:
        json.dump(transactions, file)

# Function to load transactions from a file
def load_transactions():
    try:
        with open("transactions.json", "r") as file:
            return json.load(file)
    except FileNotFoundError:
        return []

def main():
    transactions = load_transactions()
    expenses = [transaction["amount"] for transaction in transactions if transaction["amount"] < 0]
    income = sum([transaction["amount"] for transaction in transactions if transaction["amount"] > 0])

    while True:
        print("\n1. Add Expense")
        print("2. Add Income")
        print("3. View Remaining Budget")
        print("4. Analyze Expenses")
        print("5. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            expense = input_transaction()
            expenses.append(expense["amount"])
            transactions.append(expense)
            save_transactions(transactions)
            print("Expense added successfully!")
        elif choice == "2":
            income_transaction = input_transaction()
            income += income_transaction["amount"]
            transactions.append(income_transaction)
            save_transactions(transactions)
            print("Income added successfully!")
        elif choice == "3":
            remaining_budget = calculate_budget(income, expenses)
            print("Remaining Budget:", remaining_budget)
        elif choice == "4":
            category_expenses = analyze_expenses(transactions)
            print("Expense Analysis:")
            for category, amount in category_expenses.items():
                print(f"{category}: {amount}")
        elif choice == "5":
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
